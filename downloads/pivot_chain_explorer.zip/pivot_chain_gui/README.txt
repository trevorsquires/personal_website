The Pivot Chain Explorer allows one to search for all possible pivot chains of a particular length that include particular types.
Simply select the type 1 and type 2 of the type you wish to include in the chain, add it to the running list of types to search for, specify the chain length you want to search in, and then press search.

To use the tool, simply unzip all of the files into a new folder and run the executable.  DISCLAIMER: I am not a proper software dev and have less than 2 hours experience putting something like this together for other's use.  As such, you will probably see that there is no publisher information on the .exe and so your firewall might block it.  It should be fairly easy to "trust anyway" on most OS but I don't fully know for sure.  If you have low hanging fruit recommendations, I'd be happy to hear them at trevorsquires9@gmail.com

A few notes about using the tool:

- All types are encoded as dual types.  So monotypes much be searched by putting them in type1 and type2, e.g. fire/fire.
- There is no way to remove a type from the running list.  To do so, you must start over.
- No type is necessary to be added.  If you search without a type list, it will return all pivot chains of the given chain length.
- Chain length is not necessary to be specified.  If you search without a chain length, it will return all pivot chains that contain the type you're searching for.
- If you do not specify a type nor a chain length, it will return all thousand or so resistance complete pivot chains.
- The types within a chain are not ordered in any way.  You may have to reason yourself as to how you would actually pivot through these types.

DISCLAIMER: I am not a proper software dev and have less than 2 hours experience putting something like this together for other's use.  If you have low hanging fruit recommendations, I'd be happy to hear them at trevorsquires9@gmail.com
